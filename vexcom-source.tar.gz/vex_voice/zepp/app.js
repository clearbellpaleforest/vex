/*
 * VexCom — app entry.  app.js
 *
 * Zepp OS requires a root App() entry. Keep it minimal; the UI lives in
 * pages/index.js and the phone-side service in app-side/index.js.
 */
App({
  globalData: {},
  onCreate() {},
  onDestroy() {},
})