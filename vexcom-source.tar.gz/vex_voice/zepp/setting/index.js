/*
 * VexCom — settings page.  setting/index.js
 *
 * Runs inside the Zepp phone app's app-settings webview. Lets each user enter
 * their own Vex server URL and token; both are persisted to SettingsStorage and
 * read back by the side service (app-side/index.js) at request time.
 *
 * The settings JSX components (AppSettingsPage, View, Text, TextInput) are
 * injected as globals by the Zepp app-settings runtime — no imports needed.
 *
 * API refs (verified against docs.zepp.com):
 *   AppSettingsPage / settingsStorage:
 *     https://docs.zepp.com/docs/1.0/guides/framework/app-settings/register/
 *   TextInput:
 *     https://docs.zepp.com/docs/v2/reference/app-settings-api/ui/textinput/
 */
AppSettingsPage({
  build(props) {
    const serverUrl = props.settingsStorage.getItem('serverUrl') || ''
    const token = props.settingsStorage.getItem('token') || ''

    return View(
      {
        style: {
          padding: '16px 20px',
          display: 'flex',
          flexDirection: 'column',
        },
      },
      [
        Text(
          {
            style: {
              fontSize: '20px',
              fontWeight: 'bold',
              color: '#0b1b24',
              marginBottom: '4px',
            },
          },
          ['VexCom'],
        ),
        Text(
          {
            style: {
              fontSize: '13px',
              color: '#5a6b74',
              marginBottom: '20px',
            },
          },
          ['Point the watch app at your own Vex server. Both fields are stored on this phone only.'],
        ),

        View(
          {
            style: {
              padding: '12px',
              marginBottom: '14px',
              border: '1px solid #eaeaea',
              borderRadius: '8px',
              backgroundColor: 'white',
            },
          },
          [
            TextInput({
              label: 'Vex server URL',
              placeholder: 'https://your-box.your-tailnet.ts.net',
              value: serverUrl,
              subStyle: { color: '#8a99a0', fontSize: '12px' },
              onChange: (val) => {
                props.settingsStorage.setItem('serverUrl', (val || '').trim())
              },
            }),
          ],
        ),

        View(
          {
            style: {
              padding: '12px',
              marginBottom: '14px',
              border: '1px solid #eaeaea',
              borderRadius: '8px',
              backgroundColor: 'white',
            },
          },
          [
            TextInput({
              label: 'Vex token',
              placeholder: 'contents of ~/.vex_token',
              value: token,
              subStyle: { color: '#8a99a0', fontSize: '12px' },
              onChange: (val) => {
                props.settingsStorage.setItem('token', (val || '').trim())
              },
            }),
          ],
        ),

        Text(
          {
            style: {
              fontSize: '12px',
              color: '#8a99a0',
            },
          },
          ['The URL must be https:// — the Zepp app blocks plain http://.'],
        ),
      ],
    )
  },
})