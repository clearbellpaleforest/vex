/*
 * VexCom — device app (watch UI).  Lives at: pages/index.js
 *
 * v1: tap a prompt -> ask Vex -> show Vex's grounded reply.
 * The watch has no internet; this page sends the message over BLE to the
 * app-side service (app-side/index.js), which Fetches the Vex server.
 *
 * v2 (later): "hold to talk" records audio (@zos/media RECORDER) and the reply
 * plays through the speaker — "papo calling starship Vex."
 *
 * Needs `@zeppos/zml`:  npm i @zeppos/zml
 * NOTE: written without a simulator on hand — verify widget props in `zeus dev`;
 * small tweaks are expected.
 */
import { createWidget, widget, align, prop, text_style } from '@zos/ui'
import { BasePage } from '@zeppos/zml/base-page'

const PROMPTS = ['how are you?', "what's next for us?", 'status']

Page(
  BasePage({
    build() {
      createWidget(widget.TEXT, {
        x: 0, y: 36, w: 480, h: 56,
        text: 'starship Vex', text_size: 40, color: 0x9fe0ff,
        align_h: align.CENTER_H, align_v: align.CENTER_V,
      })

      this.reply = createWidget(widget.TEXT, {
        x: 30, y: 250, w: 420, h: 200,
        text: 'tap a prompt…', text_size: 24, color: 0xffffff,
        align_h: align.CENTER_H, align_v: align.TOP,
        text_style: text_style.WRAP,
      })

      PROMPTS.forEach((p, i) => {
        createWidget(widget.BUTTON, {
          x: 60, y: 104 + i * 46, w: 360, h: 40, radius: 20,
          text: p, text_size: 22,
          normal_color: 0x1b3a4b, press_color: 0x2a5a72,
          click_func: () => this.ask(p),
        })
      })
    },

    ask(message) {
      this.reply.setProperty(prop.TEXT, 'Vex is thinking…')
      this.request({ method: 'ASK', params: { message } })
        .then((data) => {
          this.reply.setProperty(prop.TEXT, (data && data.reply) || '(no reply)')
        })
        .catch((err) => {
          this.reply.setProperty(prop.TEXT, 'could not reach Vex:\n' + err)
        })
    },
  })
)