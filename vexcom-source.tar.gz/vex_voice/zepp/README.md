# VexCom — Amazfit watch app (verified build guide)

Talk to Vex from an Amazfit **Active Max** (Zepp OS 5, 480×480, `deviceSource 10813697`).
The watch has no internet, so:

```
watch (device app)  --BLE-->  phone (app-side service)  --HTTPS fetch-->  Vex server (/ask)
```

## Files (drop-ins for a zeus project)
- `pages/index.js` — watch UI (v1: tap a prompt → Vex's reply on screen). *[verified `@zos/ui`]*
- `app-side/index.js` — phone-side service; HTTPS fetch to `/ask`. *[verified ZML + this.fetch]*
- `app.json` — configured for the Active Max target (`deviceSource 10813697`, 480×480).
- `package.json` — declares `@zeppos/zml`.

---

## Step 0 — make the Vex server reachable over HTTPS (the gotcha)
The phone-side `fetch` runs inside the Zepp Android app, which **blocks plain http://**.
Serve the daemon over TLS with Tailscale (private, sovereign, no manual certs):

```bash
# on the Vex box
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
tailscale serve https / http://127.0.0.1:8520     # proxies TLS -> localhost:8520
tailscale serve status                             # shows your https://<box>.<tailnet>.ts.net URL
```
Install Tailscale on your **phone**, sign in with the **same account** (it joins the tailnet).
The daemon stays bound to `127.0.0.1` — Tailscale terminates TLS and proxies in.

Put that `https://…ts.net` URL + your `~/.vex_token` into `app-side/index.js` (`VEX_URL`, `VEX_TOKEN`).

## Step 1 — toolchain
```bash
npm i -g @zeppos/zeus-cli     # Node >= 14; Linux simulator supported
```

## Step 2 — make the project
**Easy path (recommended):**
```bash
zeus create vexcom
# answers: template=Empty · type=APP · app-side=Yes · settings=No · target=a 480x480 round device (GTR 3 Pro)
cd vexcom && npm i @zeppos/zml
```
Then copy in `pages/index.js` and `app-side/index.js` from here (overwrite the generated
ones), and set `VEX_URL` + `VEX_TOKEN` in `app-side/index.js`.

**Or** use the `app.json` here (already keyed to the Active Max, `deviceSource 10813697`) —
just add an `assets/icon.png` and an `assets/480x480-active-max/` folder for resources.

## Step 3 — test in the simulator
```bash
zeus dev      # start the Zepp OS simulator first; tap a prompt, confirm it calls out
```

## Step 4 — install on the watch
1. **Zepp app → Profile → Settings → About → tap the Zepp icon 7×** → Developer Mode toggle appears.
2. `zeus preview` in the project root → pick the target → a **QR code** prints.
3. **Zepp app → Profile → your watch → Developer Mode → Scan** the QR → it installs on the watch.
   (Camera can't read a terminal QR? Screenshot it and use the gallery option.)
4. Open **VexCom** on the watch, tap a prompt → Vex answers, grounded in its memory.

---

## Verified notes
- `@zos/ui`: `widget.TEXT`/`widget.BUTTON` props + `click_func` confirmed. On API 4.0+ you may
  use `w.text = '…'` instead of `setProperty(prop.TEXT, …)` (both work).
- ZML: `this.request({method,params})` (device) ↔ `onRequest(req,res)` with `res(null,data)`
  (app-side). Keep the **same `@zeppos/zml` version** on both sides.
- `this.fetch` response `body` is already parsed for JSON.
- v2 voice is feasible: `@zos/media` RECORDER (OPUS) + PLAYER confirmed on devices with mic+speaker.

## Sources
- [Zeus CLI](https://docs.zepp.com/docs/guides/tools/cli/) · [app.json](https://docs.zepp.com/docs/reference/app-json/)
- [Device list (Active Max)](https://docs.zepp.com/docs/reference/related-resources/device-list/)
- [@zos/ui BUTTON](https://docs.zepp.com/docs/reference/device-app-api/newAPI/ui/widget/BUTTON/) · [@zos/media](https://docs.zepp.com/docs/reference/device-app-api/newAPI/media/)
- [ZML](https://github.com/zepp-health/zml) · [side-service fetch](https://docs.zepp.com/docs/reference/side-service-api/fetch/)
- [Preview on a watch](https://docs.zepp.com/docs/guides/quick-start/preview/) · [Tailscale serve](https://tailscale.com/kb/1242/tailscale-serve)

_The JS was written without a simulator on hand; verify props in `zeus dev` — small tweaks expected._