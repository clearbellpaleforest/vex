/*
 * VexCom — app-side service (runs inside the Zepp phone app).  app-side/index.js
 *
 * The only piece with internet. Receives the watch's BLE request, calls the Vex
 * server's POST /ask, returns Vex's reply over BLE.
 *
 * The server URL + token are NOT hardcoded — each user enters their own in the
 * app settings screen (setting/index.js). They are persisted to SettingsStorage
 * and read here at request time via the ZML BaseSideService `this.settings`
 * accessor (settingsLib -> settings.settingsStorage.getItem).
 *   settings-storage ref:
 *     https://docs.zepp.com/docs/1.0/guides/framework/app-settings/register/
 *
 * IMPORTANT — HTTPS: the phone-side fetch runs in the Zepp Android app, which
 * blocks plain http://. The server URL must be served over TLS. Easiest, on the
 * Vex box:  tailscale serve https / http://127.0.0.1:8520  which yields an
 * https://<box>.<tailnet>.ts.net URL to paste into the settings screen.
 */
import { BaseSideService } from '@zeppos/zml/base-side'

AppSideService(
  BaseSideService({
    onRequest(req, res) {
      if (req.method !== 'ASK') {
        res('unknown method: ' + req.method)
        return
      }

      const serverUrl = (this.settings.getItem('serverUrl') || '').trim()
      const token = (this.settings.getItem('token') || '').trim()

      if (!serverUrl || !token) {
        res(null, {
          reply: 'Set your Vex server URL and token in the app settings.',
        })
        return
      }

      this.fetch({
        url: serverUrl + '/ask',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: 'Bearer ' + token,
        },
        body: JSON.stringify({ message: req.params.message }),
        timeout: 60000,
      })
        .then((resp) => {
          // ZML fetch parses JSON responses — resp.body is usually an object.
          let data = resp && resp.body
          if (typeof data === 'string') {
            try { data = JSON.parse(data) } catch (e) { data = {} }
          }
          res(null, { reply: (data && data.reply) || '(no reply)' })
        })
        .catch((err) => res('fetch failed: ' + err))
    },
  })
)